﻿namespace QUAN_LY_COFFEE
{


    partial class dsxuathoadon
    {
        partial class chitiethoadonDataTable
        {
        }

        partial class menuDataTable
        {
        }
    }
}
