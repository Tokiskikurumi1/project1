﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QUAN_LY_COFFEE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            txttk.KeyDown += new KeyEventHandler(TextBox_KeyDown);
            txtmk.KeyDown += new KeyEventHandler(TextBox_KeyDown);
        }
        string chuoi = @"Data Source=KURUMI\KURUMI;Initial Catalog=Quan_ly_coffee;Persist Security Info=True;User ID=sa;Password=Tokisakikurumi1@";
        SqlConnection conn;
        SqlCommand cmd;
        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnDN.PerformClick();
            }
        }


        void check()
        {
            if (sw_check.Checked)
            {
                txtmk.UseSystemPasswordChar = false;
            }
            else
            {
                txtmk.UseSystemPasswordChar= true;
            }
        }

        private void btnDN_Click(object sender, EventArgs e)
        {
            string username = txttk.Text;
            string password = txtmk.Text;

            using (conn = new SqlConnection(chuoi))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT 1 FROM UserDN WHERE nameuser = @username AND pass = @password";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);

                        // Thực thi câu lệnh và kiểm tra xem có kết quả trả về hay không.
                        var result = cmd.ExecuteScalar();

                        if (result != null)
                        {
                            MessageBox.Show("Đăng nhập thành công", "Thông báo");
                            Main main = new Main();
                            this.Hide();
                            main.ShowDialog();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Tài khoản hoặc mật khẩu không đúng. Vui lòng thử lại.", "Đăng nhập thất bại", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    conn.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void sw_check_CheckedChanged(object sender, EventArgs e)
        {
            check();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
