﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using BLL_DA;

namespace QUAN_LY_COFFEE
{
    public partial class Quan_ly_menu : Form
    {
        BLL load = new BLL();
        public Main frm;
        SqlDataAdapter adapter;
        DataTable dt;

        public Quan_ly_menu()
        {
            InitializeComponent();
            frm = new Main();
        }

        private void Quan_ly_menu_Load(object sender, EventArgs e)
        {
            ccbmenu.SelectedIndexChanged += ccbmenu_SelectedIndexChanged;
            loadccb();
            LoadMenu("Tất cả");
            loadcombobox();
            chinhcolumns();
        }

        void loadccb()
        {
            ccbmenu.DropDownStyle = ComboBoxStyle.DropDownList;
            cbbchonmenu.DropDownStyle = ComboBoxStyle.DropDownList;
            ccbmenu.Items.Add("Tất cả");
            ccbmenu.Items.Add("Cà phê");
            ccbmenu.Items.Add("Trà sữa");
            ccbmenu.Items.Add("Trà");
            ccbmenu.Items.Add("Sinh tố");
            ccbmenu.SelectedIndex = 0;
        }

        //LOAD MENU THEO COMBOBOX
        private void LoadMenu(string item)
        {
            try
            {
                if (item == "Tất cả")
                {
                    dt = load.loadquery("menu");
                }
                else if (item == "Cà phê")
                {
                    
                    dt = load.loadDM('1'); 
                }
                else if (item == "Trà sữa")
                {
                    dt = load.loadDM('2');
                }
                else if (item == "Trà")
                {
                    dt = load.loadDM('3');
                }
                else if (item == "Sinh tố")
                {
                    dt = load.loadDM('4');
                }
                dgvqlmenu.DataSource = dt;
                frm.load();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}");
            }
        }


        private void chinhcolumns()
        {
            dgvqlmenu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvqlmenu.TopLeftHeaderCell.Value = "STT";
            dgvqlmenu.Columns[0].FillWeight = 10;
            dgvqlmenu.Columns[1].FillWeight = 50;
            dgvqlmenu.Columns[2].FillWeight = 20;
            dgvqlmenu.Columns[3].FillWeight = 20;

            dgvqlmenu.Columns["id"].HeaderText = "ID";
            dgvqlmenu.Columns["ten"].HeaderText = "Tên";
            dgvqlmenu.Columns["gia"].HeaderText = "Giá";
            dgvqlmenu.Columns["madanhmuc"].HeaderText = "Mã danh mục";

            dgvqlmenu.Columns["madanhmuc"].Visible = false;

        }

        //THÊM MÓN VÀO MENU
        private void btnthem_Click(object sender, EventArgs e)
        {
            int id;
            string name = txtten.Text;
            int gia;
            string maDanhMuc = cbbchonmenu.SelectedValue?.ToString();

            if (string.IsNullOrWhiteSpace(txtid.Text) || string.IsNullOrWhiteSpace(txtten.Text) || string.IsNullOrWhiteSpace(txtgia.Text))
            {
                MessageBox.Show("Không được để trống ô");
                return;
            }

            if (!int.TryParse(txtid.Text, out id))
            {
                MessageBox.Show("ID phải là số nguyên!");
                return;
            }

            if (!int.TryParse(txtgia.Text, out gia))
            {
                MessageBox.Show("Giá phải là số nguyên!");
                return;
            }

            string errorMessage;
            if (load.ThemMonAn(id, name, gia, maDanhMuc, out errorMessage))
            {
                MessageBox.Show("Thêm thành công!");
                LoadMenu("Tất cả");
                reset();
            }
            else
            {
                MessageBox.Show(errorMessage);
            }
        }

        //SỬA MÓN MENU
        private void btnsua_Click(object sender, EventArgs e)
        {
            int id;
            string name = txtten.Text;
            int gia;
            string maDanhMuc = cbbchonmenu.SelectedValue?.ToString();

            if (string.IsNullOrWhiteSpace(txtid.Text) || string.IsNullOrWhiteSpace(txtten.Text) || string.IsNullOrWhiteSpace(txtgia.Text))
            {
                MessageBox.Show("Không được để trống ô");
                return;
            }

            if (!int.TryParse(txtid.Text, out id))
            {
                MessageBox.Show("ID phải là số nguyên!");
                return;
            }

            if (!int.TryParse(txtgia.Text, out gia))
            {
                MessageBox.Show("Giá phải là số nguyên!");
                return;
            }

            string errorMessage;
            if (load.SuaMonAn(id, name, gia, maDanhMuc, out errorMessage))
            {
                MessageBox.Show("Thay đổi thông tin thành công!", "Thông báo", MessageBoxButtons.OK);
                LoadMenu("Tất cả");
                reset();
            }
            else
            {
                MessageBox.Show(errorMessage);
            }           
            LoadMenu("Tất cả");
            reset();
        }

        //XÓA MÓN MENU
        private void btnxoa_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (string.IsNullOrEmpty(txtid.Text))
                {
                    MessageBox.Show("Vui lòng chon món cần xóa!", "Thông báo", MessageBoxButtons.OK);
                    return;
                }
                string errormesage;
                int id = Convert.ToInt32(txtid.Text);
                if (load.XoaMon("menu",id, out errormesage))
                {
                    MessageBox.Show("Xóa thành công");
                    reset();
                }
                else
                {
                    MessageBox.Show("loi");
                }
                
                LoadMenu("Tất cả");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}");
            }
        }

        private void ccbmenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            string danhmuc = ccbmenu.SelectedItem.ToString();
            LoadMenu(danhmuc);
        }

        private void dgvqlmenu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int i = e.RowIndex;
                txtid.Text = dgvqlmenu[0, i].Value.ToString();
                txtten.Text = dgvqlmenu[1,i].Value.ToString();
                txtgia.Text = dgvqlmenu[2,i].Value.ToString();
                cbbchonmenu.SelectedValue = dgvqlmenu[3,i].Value.ToString();
            }
        }

        private void btntk_Click(object sender, EventArgs e)
        {
            try
            {
                dt = load.Search(txtsearch.Text);
                dgvqlmenu.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tìm kiếm: {ex.Message}");
            }
        }

        private void loadcombobox()
        {
            try
            {
                dt = load.loadCCB();
                cbbchonmenu.DisplayMember = "tendanhmuc";  
                cbbchonmenu.ValueMember = "madanhmuc";
                cbbchonmenu.DataSource = dt;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}");
            }
        }

        private void tbnmoi_Click(object sender, EventArgs e)
        {
            reset();
        }
        void reset()
        {
            txtid.Clear();
            txtten.Clear();
            txtgia.Clear();
            txtsearch.Clear();
            ccbmenu.SelectedIndex = 0;
            cbbchonmenu.SelectedIndex = 0;
        }


        private void dgvqlmenu_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            string rowNumber = (e.RowIndex + 1).ToString();

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, dgvqlmenu.RowHeadersWidth, e.RowBounds.Height);

            using (var centerFormat = new StringFormat() { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
            {
                e.Graphics.DrawString(rowNumber, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);
            }
        }
    }
}
