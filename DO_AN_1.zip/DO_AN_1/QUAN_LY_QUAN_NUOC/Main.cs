﻿using QUAN_LY_COFFEE.thongke;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using BLL_DA;
using System.Reflection;
using DTO_DA;
namespace QUAN_LY_COFFEE
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
            btn();            
        }
        void btn()
        {
            Button[] buttons = { btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12 };

            // duyệt qua mảng các button và gắn sự kiện click
            foreach (Button btn in buttons)
            {
                btn.Click += btnBan_Click;
            }
        }
        int chonban = -1;
        DataTable dt;
        BLL bl = new BLL();
        DTO dl = new DTO();
        private void Main_Load(object sender, EventArgs e)
        {
            dt = bl.loadquery("menu");
            dgvmenu.DataSource = dt;
            loadban();
            chinhdgv();
            txttenmon.ReadOnly = true;
            txtgiatien.ReadOnly = true;
        }
        //CHỈNH DATA GIRDVIEW
        public void chinhdgv()
        {
            // Đặt chế độ tự động điều chỉnh độ rộng cột
            dgvmenu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvhoadon.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;


            dgvmenu.Columns[0].FillWeight = 10;
            dgvmenu.Columns[1].FillWeight = 70;
            dgvmenu.Columns[2].FillWeight = 20;

            dgvmenu.TopLeftHeaderCell.Value = "STT";
            dgvmenu.RowPostPaint += dgvmenu_RowPostPaint;
            dgvmenu.Columns["id"].HeaderText = "ID";
            dgvmenu.Columns["ten"].HeaderText = "Tên món";
            dgvmenu.Columns["gia"].HeaderText = "Giá";

            //HÓA ĐƠN

            dgvhoadon.Columns[0].FillWeight = 10;
            dgvhoadon.Columns[1].FillWeight = 55;
            dgvhoadon.Columns[2].FillWeight=  20;
            dgvhoadon.Columns[3].FillWeight = 25;

            //ẨN CỘT
            dgvmenu.Columns[0].Visible = false;
            dgvmenu.Columns[3].Visible = false;
            dgvhoadon.Columns[0].Visible = false;
        }
        public void load()
        {
            try
            {
                dt = bl.loadquery("menu");
                dgvmenu.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi kết nốt: {ex.Message}");
            }
        }

        private void thốngKêDoanhThuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            thongkedoanhthu tk = new thongkedoanhthu();
            tk.ShowDialog();
        }

        private void sảnPhẩmBánChạyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sanphambanchay spbc = new sanphambanchay();
            spbc.ShowDialog();
        }

        private void quảnLýMenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Quan_ly_menu quanLyMenuForm = new Quan_ly_menu();
            quanLyMenuForm.frm = this;  
            quanLyMenuForm.Show();
        }

        private void quảnLýHóaĐơnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Quan_ly_hoa_don qlhd = new Quan_ly_hoa_don();
            qlhd.sp = new sanphambanchay();
            qlhd.Show();
        }
        private void bttimkiem_Click(object sender, EventArgs e)
        {
            DataView dv = dt.DefaultView;
            dv.RowFilter = $"ten LIKE '%{txtnhap.Text}%'";
            dgvmenu.DataSource = dv;
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void thôngTinTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Thongtintaikhoancs tt = new Thongtintaikhoancs();
            tt.ShowDialog();
        }

        private void Main_Click(object sender, EventArgs e)
        {
            txtnhap.Focus();
            chonban = -1;
            btxoa.Enabled = true;
        }

        private void dgvmenu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // tránh ấn vào cột tiêu đề
            {
                int i = e.RowIndex;
                txttenmon.Text = dgvmenu[1, i].Value.ToString();
                txtgiatien.Text = dgvmenu[2, i].Value.ToString();
            }
        }

        private void btthemmon_Click(object sender, EventArgs e)
        {
            
            if (dgvmenu.SelectedRows.Count >= 0)
            {
                try
                {
                    if(countsl.Value == 0)
                    {
                        MessageBox.Show("Số lượng tối thiêu là 1");
                        countsl.Value = 1;
                        return;
                    }
                    int gia;
                    if (int.TryParse(txtgiatien.Text, out gia))
                    {
                        gia = gia * (int)countsl.Value;
                        dgvhoadon.Rows.Add(dgvmenu.SelectedRows[0].Cells["id"].Value, txttenmon.Text, countsl.Value, gia);
                        txttenmon.Clear();
                        txtgiatien.Clear();
                        countsl.Value = 1;

                        tonghoadon();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi thêm món: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một món để thêm.");
            }
        }


        private void btxoa_Click(object sender, EventArgs e)
        {
            if (dgvhoadon.Rows.Count > 0)//dung de tranh viec chon hang tieu de trong datagirdview
            {
                foreach (DataGridViewRow row_xoa in dgvhoadon.SelectedRows)
                {
                    if (!row_xoa.IsNewRow) // kiem tra xem nguoi dung co an vao dong cuoi khong
                    {
                        dgvhoadon.Rows.Remove(row_xoa);

                        tonghoadon();
                    }
                }
            }
        }

        //button đạt ban
        private void btdatban_Click(object sender, EventArgs e)
        {
            if (chonban != -1)
            {
                try
                {
                    if (dgvhoadon.Rows.Count == 0 || dgvhoadon.Rows[0].Cells[0].Value == null)
                    {
                        MessageBox.Show("Không có món ăn nào trong hóa đơn.");
                        return;
                    }

                    string tongText = Regex.Replace(lbtong.Text, @"[^\d]", "");
                    int tongtien = int.TryParse(tongText, out int total) ? total : 0;

                    if (tongtien == 0)
                    {
                        MessageBox.Show("Tổng tiền không hợp lệ.");
                        return;
                    }

                    int mahoadon = bl.DatBan(chonban, tongtien);

                    if (mahoadon > 0)
                    {
                        MessageBox.Show("Bàn đã được đặt thành công!");

                        List<DTO.ChiTietHoaDon> danhSach = new List<DTO.ChiTietHoaDon>();

                        foreach (DataGridViewRow row in dgvhoadon.Rows)
                        {
                            if (row.IsNewRow) continue;

                            danhSach.Add(new DTO.ChiTietHoaDon
                            {
                                MaHoaDon = mahoadon,
                                IdMenu = Convert.ToInt32(row.Cells[0].Value),
                                SoLuong = Convert.ToInt32(row.Cells[2].Value),
                                Gia = Convert.ToInt32(row.Cells[3].Value)
                            });
                        }

                        bl.LuuChiTiet(mahoadon, danhSach); // Gọi phương thức mới

                        dgvhoadon.Rows.Clear();
                        tonghoadon();
                        loadban();
                    }
                    else
                    {
                        MessageBox.Show("Bàn đã có người đặt.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi đặt bàn: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn bàn trước khi đặt!");
            }
        }


        //BUTTON THANH TOAN
        private void btthanhtoan_Click(object sender, EventArgs e)
        {
            if (chonban != -1)
            {
                int tra_ve = bl.thanhtoan(chonban);
                try
                {
                    if(tra_ve == -1)
                    {
                        MessageBox.Show("Bàn không có hóa đơn");
                        chonban = -1;
                    }
                    else if (tra_ve == -2)
                    {
                        MessageBox.Show("Thanh toán lỗi");
                        chonban = -1;
                    }
                    else
                    {
                        MessageBox.Show("Thanh toán thành công, bàn đã được làm trống!");
                        // Cập nhật lại giao diện
                        dgvhoadon.Rows.Clear(); // Xóa danh sách hóa đơn hiện tại
                        chonban = -1; // Reset bàn đã chọn
                        btxoa.Enabled = true;
                        tonghoadon();
                        loadban();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi thanh toán: {ex.Message}");
                }
            }
            else if(chonban==-1)
            {
                try
                {
                    if(!hoadontrong(dgvhoadon))
                    {
                        //ketnoi();
                        string tongText = Regex.Replace(lbtong.Text, @"[^\d]", ""); // Giữ lại các chữ số
                        int tongtien = 0;

                        if (!int.TryParse(tongText, out tongtien))
                        {
                            MessageBox.Show("Tổng tiền không hợp lệ. Vui lòng kiểm tra lại.");
                            return;
                        }
                        int mahoadon = bl.ThanhToan(tongtien);
                        List<DTO.ChiTietHoaDon> danhSach = new List<DTO.ChiTietHoaDon>();

                        foreach (DataGridViewRow row in dgvhoadon.Rows)
                        {
                            if (row.IsNewRow) continue;

                            danhSach.Add(new DTO.ChiTietHoaDon
                            {
                                MaHoaDon = mahoadon,
                                IdMenu = Convert.ToInt32(row.Cells[0].Value),
                                SoLuong = Convert.ToInt32(row.Cells[2].Value),
                                Gia = Convert.ToInt32(row.Cells[3].Value)
                            });
                        }
                        bl.LuuChiTiet(mahoadon, danhSach);
                        MessageBox.Show("Thanh toán thành công");
                        dgvhoadon.Rows.Clear();
                        tonghoadon();
                        //ngatkn();
                    }
                    else
                    {
                        MessageBox.Show("Hóa đơn trống","Thông báo",MessageBoxButtons.OK);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi thanh toán: {ex.Message}");
                }
            }
        }
        private bool hoadontrong(DataGridView dgv)
        {
            // Duyệt qua tất cả các hàng
            foreach (DataGridViewRow row in dgv.Rows)
            {
                // Nếu hàng không phải là hàng mới (thường xuất hiện ở cuối DataGridView)
                if (!row.IsNewRow)
                {
                    // Kiểm tra cột đầu tiên (hoặc bất kỳ cột nào) có dữ liệu hay không
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        if (cell.Value != null && !string.IsNullOrWhiteSpace(cell.Value.ToString()))
                        {
                            return false; // Có dữ liệu
                        }
                    }
                }
            }
            return true; // Không có dữ liệu
        }


        void HienThiThongTinBan(int idban)
        {
            try
            {
                int tongTien = 0;
                dt = bl.hienthiban(idban);
                dgvhoadon.Rows.Clear(); // Xóa các dòng cũ
                foreach (DataRow rowChiTiet in dt.Rows)
                {
                    dgvhoadon.Rows.Add(rowChiTiet["idmenu"], rowChiTiet["ten"], rowChiTiet["soluong"], rowChiTiet["gia"]);

                    // Tính tổng tiền
                    tongTien += Convert.ToInt32(rowChiTiet["gia"]);
                }

                // Hiển thị tổng tiền
                lbtong.Text = $"{tongTien:N0} VND"; // Định dạng tổng tiền
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}");
            }
        }


        //TÍNH TỔNG TIỀN 
        void tonghoadon()
        {
            int tong = 0;
            foreach (DataGridViewRow row_tong in dgvhoadon.Rows)
            {
                if (row_tong.Cells[3].Value != null)
                {
                    int trave;
                    if (int.TryParse(row_tong.Cells[3].Value.ToString(), out trave))
                    {
                        tong += trave;
                    }
                }
            }
            lbtong.Text = $"{tong:N0} VND";
        }

        //LOAD BÀN
        private void loadban()
        {

            try
            {
                dt = bl.loadquery("ban");
                get_button(dt);                                  
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        // lấy dữ liệu từ datatable để đổ vào button
        private void get_button(DataTable dt)
        {
            foreach (DataRow row in dt.Rows)
            {
                int idban = Convert.ToInt32(row["idban"]);
                string tenban = row["tenban"].ToString();
                string trangthai = row["trangthai"].ToString();
                update_btn_chon($"btn{idban}", $"{tenban}\n{trangthai}"); // hiển thị tên bàn và trạng thái, ép id bàn thành namebutton để cập nhật trạng thái                 
            }
        }

        // cập nhật trạng thái và màu button
        private void update_btn_chon(string buttonName, string text)
        {
            Control[] controls = this.Controls.Find(buttonName, true); // lấy name của button

            if (controls.Length > 0 && controls[0] is Button button)
            {
                button.Text = text;

                // Tùy chỉnh màu sắc của button theo trạng thái
                if (text.Contains("Trống"))
                {
                    button.BackColor = Color.LightGreen; // Màu cho trạng thái Trống
                }
                else if (text.Contains("Có người"))
                {
                    button.BackColor = Color.LightCoral; // Màu cho trạng thái Có người
                }
            }
        }

        // hiển thị bàn được chọn 
        private void btnBan_Click(object sender, EventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton != null) // kiểm tra xem đã chọn button nào chưa
            {
                chonban = int.Parse(clickedButton.Name.Replace("btn", "")); // lấy số bàn và xóa chuỗi btn, giữ lại số đằng sau 
                // Kiểm tra trạng thái của bàn
                string tableStatus = clickedButton.Text.Contains("Có người") ? "Có người" : "Trống";

                if (tableStatus == "Có người")
                {
                    btxoa.Enabled = false;
                    //dgvhoadon.Rows.Clear();
                    try
                    {
                        //ketnoi();
                        HienThiThongTinBan(chonban);  // Hiển thị thông tin hóa đơn cho bàn
                        //ngatkn();
                        //LoadData();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Lỗi hiển thị hóa đơn: {ex.Message}");
                    }
                }
                ///
                else
                {
                    btxoa.Enabled = true;
                }
            }
        }

        private void dgvmenu_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            string rowNumber = (e.RowIndex + 1).ToString();

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, dgvmenu.RowHeadersWidth, e.RowBounds.Height);

            Font rowNumberFont = new Font(this.Font.FontFamily, 12, FontStyle.Bold);

            using (var centerFormat = new StringFormat() { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
            {
                e.Graphics.DrawString(rowNumber, rowNumberFont, SystemBrushes.ControlText, headerBounds, centerFormat);
            }
        }
    }
}
