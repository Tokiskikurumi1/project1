﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace QUAN_LY_COFFEE
{
    public partial class Thongtintaikhoancs : Form
    {
        public Thongtintaikhoancs()
        {
            InitializeComponent();
        }
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader reader;
        string chuoikn = @"Data Source=KURUMI\KURUMI;Initial Catalog=Quan_ly_coffee;Persist Security Info=True;User ID=sa;Password=Tokisakikurumi1@";
        private void Thongtintaikhoancs_Load(object sender, EventArgs e)
        {
            load();
        }

        void load()
        {
            using (conn = new SqlConnection(chuoikn))
            {
                conn.Open();
                string sql = "select * from UserDN";
                cmd = new SqlCommand(sql, conn);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    txtid.Text = reader[0].ToString();
                    txttk.Text = reader[1].ToString();
                    txtmk.Text = reader[2].ToString();
                }
                conn.Close();
            }
        }
        void ketnoi()
        {
            conn = new SqlConnection(chuoikn);
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
        }
        void ngat()
        {
            if(conn.State == ConnectionState.Open)
            {
                conn.Close() ;
            }
        }
        private void btnluu_Click(object sender, EventArgs e)
        {
            try
            {
                ketnoi();
                string tendn = txttk.Text;
                string mk = txtmk.Text;
                string id = txtid.Text;
                string sql = "UPDATE UserDN " +
                     "SET nameuser = '"+tendn+"', pass = '"+mk+"' " +
                     "WHERE id = '"+id+"'";

                cmd = new SqlCommand(sql, conn);               
                cmd.ExecuteNonQuery();
                ngat();
                MessageBox.Show("Đã cập nhật thông tin người dùng", "Thông báo", MessageBoxButtons.OK);
                txttk.Clear();
                txtmk.Clear();
                txtid.Clear();
                load();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi"+ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
