﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using BLL_DA;

namespace QUAN_LY_COFFEE
{
    public partial class sanphambanchay : Form
    {
        BLL sp = new BLL();
        public sanphambanchay()
        {
            InitializeComponent();
            cbbtt.DropDownStyle = ComboBoxStyle.DropDownList; // chỉ đọc
            cbbtt.Items.Add("Tất cả");
            cbbtt.Items.Add("Theo ngày");
            cbbtt.Items.Add("Theo tuần");
            cbbtt.Items.Add("Theo tháng");
            cbbtt.SelectedIndex = 0;
            load("Tất cả");
            loaddgv();
        }
        public void UpdateData()
        {
            load("Tất cả");
            loaddgv();
        }
        DataTable dt;

        void loaddgv()
        {
            if (dgvtk.Columns.Count > 0) // Kiểm tra nếu cột đã tồn tại
            {
                cbbtt.SelectedIndex = 0;
                dgvtk.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgvtk.TopLeftHeaderCell.Value = "STT";
                dgvtk.RowPostPaint += dgvtk_RowPostPaint;

                dgvtk.Columns[0].FillWeight = 10;
                dgvtk.Columns[1].FillWeight = 60;
                dgvtk.Columns[2].FillWeight = 30;

                dgvtk.Columns[0].HeaderText = "ID";
                dgvtk.Columns[1].HeaderText = "Tên";
                dgvtk.Columns[2].HeaderText = "Số lượng mua";

                dgvtk.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
        }



        void load(string itemccb)
        {
            try
            {
                dt = sp.LoadDGV(itemccb);
                dgvtk.DataSource = null; // Xóa binding cũ
                if (dt != null && dt.Rows.Count > 0)
                {
                    dgvtk.DataSource = dt;
                    loaddgv(); // Định dạng lại cột sau khi có dữ liệu
                }
                else
                {
                    MessageBox.Show("Không có dữ liệu để hiển thị cho: " + itemccb);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }


        private void sanphambanchay_Load(object sender, EventArgs e)
        {
            cbbtt.SelectedIndexChanged += cbbtt_SelectedIndexChanged;
        }

        private void cbbtt_SelectedIndexChanged(object sender, EventArgs e)
        {
            string itemccb = cbbtt.SelectedItem.ToString();
            load(itemccb);
        }

        private void dgvtk_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            string rowNumber = (e.RowIndex + 1).ToString();

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, dgvtk.RowHeadersWidth, e.RowBounds.Height);

            using (var centerFormat = new StringFormat() { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
            {
                e.Graphics.DrawString(rowNumber, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);
            }
        }
    }
}
