﻿namespace QUAN_LY_COFFEE.thongke
{
    partial class thongkedoanhthu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dttungay = new System.Windows.Forms.DateTimePicker();
            this.dtdenngay = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.btntk = new System.Windows.Forms.Button();
            this.dgvtk = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.lbshd = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbtdt = new System.Windows.Forms.Label();
            this.btnxuatbc = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvtk)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(776, 60);
            this.label1.TabIndex = 0;
            this.label1.Text = "THỐNG KÊ DOANH THU";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dttungay
            // 
            this.dttungay.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dttungay.Location = new System.Drawing.Point(18, 73);
            this.dttungay.Name = "dttungay";
            this.dttungay.Size = new System.Drawing.Size(200, 22);
            this.dttungay.TabIndex = 1;
            // 
            // dtdenngay
            // 
            this.dtdenngay.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtdenngay.Location = new System.Drawing.Point(398, 73);
            this.dtdenngay.Name = "dtdenngay";
            this.dtdenngay.Size = new System.Drawing.Size(200, 22);
            this.dtdenngay.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(260, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 3;
            this.label2.Text = "Đến ngày";
            // 
            // btntk
            // 
            this.btntk.AutoSize = true;
            this.btntk.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntk.Location = new System.Drawing.Point(648, 70);
            this.btntk.Name = "btntk";
            this.btntk.Size = new System.Drawing.Size(104, 31);
            this.btntk.TabIndex = 4;
            this.btntk.Text = "Thống kê";
            this.btntk.UseVisualStyleBackColor = true;
            this.btntk.Click += new System.EventHandler(this.btntk_Click);
            // 
            // dgvtk
            // 
            this.dgvtk.BackgroundColor = System.Drawing.Color.White;
            this.dgvtk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvtk.Location = new System.Drawing.Point(18, 123);
            this.dgvtk.Name = "dgvtk";
            this.dgvtk.ReadOnly = true;
            this.dgvtk.RowHeadersWidth = 51;
            this.dgvtk.RowTemplate.Height = 24;
            this.dgvtk.Size = new System.Drawing.Size(580, 315);
            this.dgvtk.TabIndex = 5;
            this.dgvtk.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvtk_RowPostPaint);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(654, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 23);
            this.label3.TabIndex = 6;
            this.label3.Text = "Số hóa đơn:";
            // 
            // lbshd
            // 
            this.lbshd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbshd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbshd.Location = new System.Drawing.Point(776, 181);
            this.lbshd.Name = "lbshd";
            this.lbshd.Size = new System.Drawing.Size(159, 40);
            this.lbshd.TabIndex = 7;
            this.lbshd.Text = "0";
            this.lbshd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(616, 287);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 23);
            this.label5.TabIndex = 8;
            this.label5.Text = "Tổng doanh thu:";
            // 
            // lbtdt
            // 
            this.lbtdt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbtdt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtdt.Location = new System.Drawing.Point(776, 279);
            this.lbtdt.Name = "lbtdt";
            this.lbtdt.Size = new System.Drawing.Size(159, 39);
            this.lbtdt.TabIndex = 9;
            this.lbtdt.Text = "0 VND";
            this.lbtdt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnxuatbc
            // 
            this.btnxuatbc.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnxuatbc.Location = new System.Drawing.Point(658, 369);
            this.btnxuatbc.Name = "btnxuatbc";
            this.btnxuatbc.Size = new System.Drawing.Size(277, 46);
            this.btnxuatbc.TabIndex = 10;
            this.btnxuatbc.Text = "Xuất báo cáo";
            this.btnxuatbc.UseVisualStyleBackColor = true;
            this.btnxuatbc.Click += new System.EventHandler(this.btnxuatbc_Click);
            // 
            // thongkedoanhthu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(971, 450);
            this.Controls.Add(this.btnxuatbc);
            this.Controls.Add(this.lbtdt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbshd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgvtk);
            this.Controls.Add(this.btntk);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtdenngay);
            this.Controls.Add(this.dttungay);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "thongkedoanhthu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "THỐNG KÊ DOANH THU";
            this.Load += new System.EventHandler(this.thongkedoanhthu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvtk)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dttungay;
        private System.Windows.Forms.DateTimePicker dtdenngay;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btntk;
        private System.Windows.Forms.DataGridView dgvtk;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbshd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbtdt;
        private System.Windows.Forms.Button btnxuatbc;
    }
}