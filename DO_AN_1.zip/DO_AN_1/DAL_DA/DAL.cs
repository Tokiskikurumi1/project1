﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Text.RegularExpressions;
using DTO_DA;
using System.Collections;
namespace DAL_DA
{
    public abstract class DAL
    {
        protected string chuoikn = @"Data Source=KURUMI\KURUMI;Initial Catalog=Quan_ly_coffee;Persist Security Info=True;User ID=sa;Password=Tokisakikurumi1@";
        protected SqlConnection conn;
        protected SqlCommand cmd;
        protected SqlDataAdapter adapter;
        protected DataTable dt;
        public DAL()
        {
            conn = new SqlConnection(chuoikn);
        }

        DTO dto = new DTO();

        //
        protected void KetNoi()
        {
            conn = new SqlConnection(chuoikn); // Thay bằng chuỗi kết nối của bạn
            conn.Open();
        }

        protected void NgatKn()
        {
            if (conn != null && conn.State == ConnectionState.Open)
                conn.Close();
        }
        //
        //LOAD DATAGIRD VIEW
        public DataTable dboload(string query)
        {
            dt = new DataTable();
            cmd = new SqlCommand();
            cmd.CommandText = "select * from " +query;
            cmd.Connection = conn;
            adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;
            adapter.Fill(dt);
            return dt;
        }

        // TÌM MÓN ĂN
        public DataTable dboSearch(string name)
        {
            dt = new DataTable();
            string query = $"SELECT * FROM menu WHERE ten LIKE N'%{name}%'";
            cmd = new SqlCommand(query, conn);
            adapter = new SqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }

        

        
        ///
        //THANH TOÁN BÀN
        public int ThanhToanBan(int idban)
        {
            if (idban == -1)
            {
                return -1;
            }
            try
            {
                using (SqlConnection conn = new SqlConnection(chuoikn)) // Tự động đóng kết nối
                {
                    conn.Open();

                    //kiểm tra trạng thái của bàn
                    string queryBan = $"SELECT * FROM ban WHERE idban = {idban}";
                    DataTable dtBan = new DataTable();
                    SqlDataAdapter adapterBan = new SqlDataAdapter(queryBan, conn);
                    SqlCommandBuilder builderBan = new SqlCommandBuilder(adapterBan);
                    adapterBan.Fill(dtBan);

                    if (dtBan.Rows.Count > 0) //kiểm tra xem có dữ liệu trả về hay không 
                    {
                        DataRow rowBan = dtBan.Rows[0];// gán bàn vừa tìm được
                        if (rowBan["trangthai"].ToString() == "Trống")
                        {
                            // Nếu bàn trống, thông báo không có hóa đơn
                            return -1; // Dừng thực hiện nếu bàn trống
                        }
                    }

                    //kiểm tra hóa đơn chưa thanh toán
                    string queryHoaDon = $"SELECT * FROM hoadon WHERE idban = {idban} AND tinhtrang = '0'";
                    DataTable dtHoaDon = new DataTable();
                    SqlDataAdapter adapterHoaDon = new SqlDataAdapter(queryHoaDon, conn);
                    SqlCommandBuilder builderHoaDon = new SqlCommandBuilder(adapterHoaDon);
                    adapterHoaDon.Fill(dtHoaDon);

                    // Nếu có hóa đơn chưa thanh toán, cập nhật trạng thái
                    if (dtHoaDon.Rows.Count > 0)
                    {
                        DataRow rowHoaDon = dtHoaDon.Rows[0];
                        rowHoaDon["tinhtrang"] = "1"; // Đánh dấu hóa đơn là đã thanh toán
                        adapterHoaDon.Update(dtHoaDon); // Cập nhật vào cơ sở dữ liệu
                    }

                    //cập nhật trạng thái bàn
                    if (dtBan.Rows.Count > 0)
                    {
                        DataRow rowBan = dtBan.Rows[0];
                        rowBan["trangthai"] = "Trống"; // Đánh dấu bàn là trống
                        adapterBan.Update(dtBan); // Cập nhật vào cơ sở dữ liệu
                    }
                }    
                // Thông báo thành công
                return idban;
            }
            catch (Exception ex)
            {
                return -2;
            }
        }

        //THANH TOÁN HÓA ĐƠN

        public int ThanhToanHoaDon(int tongtien)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(chuoikn))
                {
                    conn.Open();

                    // Bước 1: Thêm hóa đơn mới
                    string sqlHoadon = "SELECT * FROM hoadon";
                    SqlDataAdapter adapter = new SqlDataAdapter(sqlHoadon, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    DataRow newRow = dt.NewRow();
                    newRow["ngaytao"] = DateTime.Now;
                    newRow["hinhthuc"] = 1;  // Thanh toán ngay, không đặt bàn
                    newRow["tinhtrang"] = 1;  // Đã thanh toán
                    newRow["tongtien"] = tongtien;
                    dt.Rows.Add(newRow);

                    SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                    adapter.Update(dt);
                    int mahoadon;
                    // Bước 2: Lấy mã hóa đơn mới
                    if (newRow["mahoadon"] != DBNull.Value)
                    {
                        mahoadon = Convert.ToInt32(newRow["mahoadon"]);
                    }
                    else
                    {
                        string getmahd = "SELECT IDENT_CURRENT('hoadon') AS LastID";
                        SqlCommand cmdgethd = new SqlCommand(getmahd, conn);
                        mahoadon = Convert.ToInt32(cmdgethd.ExecuteScalar());
                    }

                    // Bước 3: Lưu chi tiết hóa đơn
                    string sqlChitiet = "SELECT * FROM chitiethoadon";
                    adapter = new SqlDataAdapter(sqlChitiet, conn);
                    dt = new DataTable();
                    adapter.Fill(dt);
                    return mahoadon; // Thành công, trả về mã hóa đơn
                }
            }
            catch
            {
                return -1; // Lỗi xảy ra
            }
        }

        //HIEN THI BAN
        public DataTable hienthiban(int idban)
        {
            string sqlChiTiet = $@"
                SELECT ct.idmenu, m.ten, ct.soluong, (ct.soluong * m.gia) as gia
                FROM ban b
                INNER JOIN hoadon hd ON b.idban = hd.idban
                INNER JOIN chitiethoadon ct ON ct.mahoadon = hd.mahoadon
                INNER JOIN menu m ON m.id = ct.idmenu
                WHERE b.idban = {idban} AND hd.tinhtrang = '0'";


            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = sqlChiTiet;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;
            adapter.Fill(dt);
            return dt;
        }


        //ĐỔ DỮ LIỆU VÀO COMBOBOX
        public DataTable GetDanhMuc()
        {
            DataTable dt = dboload("danhmuc");
            DataRow newRow = dt.NewRow();
            newRow["madanhmuc"] = DBNull.Value;
            newRow["tendanhmuc"] = "Chọn danh mục";
            dt.Rows.InsertAt(newRow, 0);

            return dt;
        }
        //CHECK ID
        public bool CheckIdExists(int id)
        {
            KetNoi();
            string query = $"SELECT COUNT(*) FROM menu WHERE id =  {id}"; // Giả sử cột là "id"
            cmd = new SqlCommand(query, conn);
            int i = (int)cmd.ExecuteScalar();
            NgatKn();
            return i > 0;
        }

    }
}
