﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace DAL_DA.DAL_FORM
{
    public class DAL_quanly : DAL
    {
        public DAL_quanly()
        {
            conn = new SqlConnection(chuoikn);
        }

        public DataTable LOAD_TONG(string query)
        {
            dt = new DataTable();
            cmd = new SqlCommand();
            cmd.CommandText = "select * from " + query;
            cmd.Connection = conn;
            adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;
            adapter.Fill(dt);
            return dt;
        }

        //LOAD MÃ DM QUẢN LÝ MENU
        public DataTable dboloadDM(char MaDM)
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from menu where madanhmuc = " + $"'DM0{MaDM}'";
            cmd.Connection = conn;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;
            adapter.Fill(dt);
            return dt;
        }
        // THÊM MÓN MENU
        public bool ThemMon(int id, string name, int gia, string maDanhMuc)
        {
            try
            {
                KetNoi();
                DataTable them = dboload("menu");
                DataRow dr = them.NewRow();
                dr["id"] = id;
                dr["ten"] = name;
                dr["gia"] = gia;
                dr["maDanhMuc"] = maDanhMuc;
                them.Rows.Add(dr);

                SqlCommandBuilder bd = new SqlCommandBuilder(adapter);
                adapter.Update(them);
                NgatKn();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                NgatKn();
            }
        }

        //SỬA MÓN TRONG MENU
        public bool SuaMenu(int id, string name, int gia, string maDanhMuc)
        {
            try
            {
                KetNoi();
                DataTable sua = dboload("menu");
                for (int i = 0; i < dt.Rows.Count; i++) //Lặp qua từng dòng dữ liệu trong dt
                {
                    if (dt.Rows[i][0].ToString() == id.ToString())
                    {
                        dt.Rows[i][1] = name;
                        dt.Rows[i][2] = gia;
                        dt.Rows[i][3] = maDanhMuc;
                    }
                }
                SqlCommandBuilder bd = new SqlCommandBuilder(adapter);
                adapter.Update(sua);
                NgatKn();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        //

        // XÓA MÓN TRONG MENU
        public bool XoaMenu(string name_table,int id)
        {
            try
            {
                KetNoi();
                dt = new DataTable();
                cmd = new SqlCommand();
                cmd.CommandText = $"delete from {name_table} where id = {id}";
                cmd.Connection = conn;
                adapter = new SqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                NgatKn();
                return true;
            }
            catch
            {
                return false;
            }
        }
        //XÓA HOAS ĐƠN
        public bool XoaHoaDon(int id)
        {
            try
            {
                KetNoi();
                dt = new DataTable();
                cmd = new SqlCommand();
                cmd.CommandText = $"delete from hoadon where mahoadon = {id}";
                cmd.Connection = conn;
                adapter = new SqlDataAdapter();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
                NgatKn();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool CheckMHD(int id)
        {
            KetNoi();
            string query = $"SELECT COUNT(*) FROM hoadon WHERE mahoadon =  {id}"; // Giả sử cột là "id"
            cmd = new SqlCommand(query, conn);
            int i = (int)cmd.ExecuteScalar();
            NgatKn();
            return i > 0;
        }

        //Thống kê doanh thu
        public DataTable ThongKeHoaDon(DateTime tuNgay, DateTime denNgay)
        {
            try
            {
                KetNoi();
                string sqlThongKe = @"SELECT mahoadon, ngaytao, hinhthuc, tinhtrang, tongtien
                                    FROM hoadon
                                    WHERE ngaytao BETWEEN @tuNgay AND @denNgay";
                cmd = new SqlCommand(sqlThongKe, conn);
                cmd.Parameters.AddWithValue("@tuNgay", tuNgay);
                cmd.Parameters.AddWithValue("@denNgay", denNgay);
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);

                NgatKn();
                return dt;
            }
            catch (Exception ex)
            {
                NgatKn();
                throw new Exception("Lỗi khi lấy dữ liệu thống kê: " + ex.Message);
            }
        }

        public DataTable GetChiTietHoaDon(int maHoaDon)
        {
            try
            {
                KetNoi();
                string sqlChiTiet = "SELECT m.id, m.ten, ct.soluong, ct.gia " +
                                   "FROM menu m " +
                                   "INNER JOIN chitiethoadon ct ON m.id = ct.idmenu " +
                                   "INNER JOIN hoadon hd ON hd.mahoadon = ct.mahoadon " +
                                   "WHERE hd.mahoadon = '" + maHoaDon + "'";

                cmd = new SqlCommand(sqlChiTiet, conn);
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);

                NgatKn();
                return dt;
            }
            catch (Exception ex)
            {
                NgatKn();
                throw new Exception("Lỗi khi lấy chi tiết hóa đơn: " + ex.Message);
            }
        }

        //
        public DataTable LayDuLieuInHoaDon(int maHoaDon)
        {
            try
            {
                KetNoi();
                string sql = "SELECT m.id, m.ten, ct.soluong, ct.gia " +
                            "FROM menu m " +
                            "INNER JOIN chitiethoadon ct ON m.id = ct.idmenu " +
                            "INNER JOIN hoadon hd ON hd.mahoadon = ct.mahoadon " +
                            "WHERE hd.mahoadon = '" + maHoaDon + "'";

                cmd = new SqlCommand(sql, conn);
                DataTable dt = new DataTable();
                adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);

                NgatKn();
                return dt;
            }
            catch (Exception ex)
            {
                NgatKn();
                throw new Exception("Lỗi khi lấy dữ liệu để in hóa đơn: " + ex.Message);
            }
        }
    }
}
