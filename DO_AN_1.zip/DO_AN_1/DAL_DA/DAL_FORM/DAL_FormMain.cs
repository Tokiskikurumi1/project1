﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using DTO_DA;

namespace DAL_DA.DAL_FORM
{
    public class DAL_FormMain : DAL
    {
        DTO dto = new DTO();
        public DAL_FormMain()
        {
            conn = new SqlConnection(chuoikn);
        }

        public DataTable LoadMain(string query)
        {
            dt = dboload(query);
            return dt;
        }




        //ĐẶT BÀN 
        public int DatBan(int idban, int tongtien)
        {
            using (SqlConnection conn = new SqlConnection(chuoikn))
            {
                try
                {
                    conn.Open();

                    // Bước 1: Kiểm tra trạng thái bàn
                    string sqlCheckBan = $"SELECT trangthai FROM ban WHERE idban = {idban}";
                    SqlCommand cmdCheck = new SqlCommand(sqlCheckBan, conn);
                    string tableStatus = cmdCheck.ExecuteScalar()?.ToString();

                    if (tableStatus == "Có người")
                    {
                        return -1; // Bàn đã có người, không thể đặt
                    }

                    // Bước 2: Thêm hóa đơn mới
                    string sqlHoadon = "SELECT * FROM hoadon";
                    SqlDataAdapter adapter = new SqlDataAdapter(sqlHoadon, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    DataRow newRow = dt.NewRow();
                    newRow["ngaytao"] = DateTime.Now;
                    newRow["hinhthuc"] = 0;
                    newRow["tinhtrang"] = 0;
                    newRow["idban"] = idban;
                    newRow["tongtien"] = tongtien;

                    dt.Rows.Add(newRow);

                    SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                    adapter.Update(dt);

                    // Bước 3: Lấy mã hóa đơn vừa thêm
                    int mahoadon;
                    if (newRow["mahoadon"] != DBNull.Value)
                    {
                        mahoadon = Convert.ToInt32(newRow["mahoadon"]);
                    }
                    else
                    {
                        string sql = "SELECT IDENT_CURRENT('hoadon') AS LastID";
                        cmd = new SqlCommand(sql, conn);
                        mahoadon = Convert.ToInt32(cmd.ExecuteScalar());
                    }

                    // Bước 4: Cập nhật trạng thái bàn
                    string sqlBan = $"UPDATE ban SET trangthai = N'Có người' WHERE idban = {idban}";
                    cmd = new SqlCommand(sqlBan, conn);
                    cmd.ExecuteNonQuery();

                    //Thêm chi tiết hóa đơn
                    string sqlChitiet = "SELECT * FROM chitiethoadon";
                    adapter = new SqlDataAdapter(sqlChitiet, conn);
                    dt = new DataTable();
                    adapter.Fill(dt);

                    return mahoadon; // Thành công
                }
                catch (Exception)
                {
                    return -2; // Lỗi
                }
            }
        }
        
        
        // LƯU CHI TIẾT HÓA ĐƠN
        public void LuuChiTietHoaDon(int mahoadon, List<DTO.ChiTietHoaDon> chiTietHoaDons)
        {
            try
            {
                string sqlChitiet = "SELECT * FROM chitiethoadon";
                adapter = new SqlDataAdapter(sqlChitiet, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                foreach (var item in chiTietHoaDons)
                {
                    DataRow newDetailRow = dt.NewRow();
                    newDetailRow["mahoadon"] = mahoadon;
                    newDetailRow["idmenu"] = item.IdMenu;
                    newDetailRow["soluong"] = item.SoLuong;
                    newDetailRow["gia"] = item.Gia;

                    dt.Rows.Add(newDetailRow);
                }

                SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                adapter.Update(dt);
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi lưu chi tiết hóa đơn: " + ex.Message);
            }
        }
    }
}
