﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Data.Common;
using System.Security.Cryptography.X509Certificates;
namespace DAL_DA.DAL_FORM
{
    public class DAL_thongke :DAL
    {
        DataTable dt;
        SqlDataAdapter adapter;
        SqlCommand cmd;
        public DAL_thongke()
        {
            conn = new SqlConnection(chuoikn);
        }

        public DataTable Load_Thong_ke()
        {
            string sql = "select mahoadon, ngaytao, hinhthuc, tongtien from hoadon";
            cmd = new SqlCommand(sql, conn);
            dt = new DataTable();
            adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dt);
            return dt;
        }

        public DataTable Thongketheongay(DateTime fromDate, DateTime toDate)
        {
            DataTable dt = new DataTable();
            string sql = @"SELECT mahoadon, ngaytao, hinhthuc, tongtien FROM hoadon 
                          WHERE ngaytao BETWEEN @FromDate AND @ToDate";


            try
            {
                KetNoi();
                cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@FromDate", fromDate);
                cmd.Parameters.AddWithValue("@ToDate", toDate);
                adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi truy xuất dữ liệu: " + ex.Message);
            }
            finally
            {
                // Đóng và giải phóng tài nguyên thủ công
                if (adapter != null)
                {
                    adapter.Dispose();
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                }
                if (conn != null && conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                    conn.Dispose();
                }
            }
            return dt;
        }


        public DataTable GetAllInvoices()
        {
            DataTable dt = new DataTable();
            string sql = "SELECT mahoadon, ngaytao, hinhthuc, tongtien FROM hoadon";

            try
            {
                KetNoi();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi lấy tất cả hóa đơn: " + ex.Message);
            }
            return dt;
        }

        // Lấy hóa đơn theo khoảng thời gian
        public DataTable GetInvoicesByDateRange(DateTime fromDate, DateTime toDate)
        {
            DataTable dt = new DataTable();
            string sql = @"SELECT mahoadon, ngaytao, hinhthuc, tongtien FROM hoadon 
                          WHERE ngaytao BETWEEN @FromDate AND @ToDate";

            try
            {
                KetNoi();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@FromDate", fromDate);
                cmd.Parameters.AddWithValue("@ToDate", toDate);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi lấy hóa đơn theo ngày: " + ex.Message);
            }
            return dt;
        }

        //SẢN PHẨM BÁN CHẠY

        public DataTable GetAllStatistics()
        {
            string sql = @"SELECT ct.idmenu, m.ten, SUM(ct.soluong) AS soluong
                          FROM menu m 
                          INNER JOIN chitiethoadon ct ON m.id = ct.idmenu 
                          INNER JOIN hoadon hd ON hd.mahoadon = ct.mahoadon
                          GROUP BY ct.idmenu, m.ten
                          ORDER BY SUM(ct.soluong) DESC";
            return ExecuteQuery(sql);
        }

        public DataTable GetStatisticsByDay()
        {
            string sql = @"SELECT ct.idmenu, m.ten, SUM(ct.soluong) AS soluong
                          FROM menu m 
                          INNER JOIN chitiethoadon ct ON m.id = ct.idmenu 
                          INNER JOIN hoadon hd ON hd.mahoadon = ct.mahoadon
                          WHERE CAST(hd.ngaytao AS DATE) = CAST(GETDATE() AS DATE)
                          GROUP BY ct.idmenu, m.ten
                          ORDER BY SUM(ct.soluong) DESC";
            return ExecuteQuery(sql);
        }

        public DataTable GetStatisticsByWeek()
        {
            string sql = @"SELECT ct.idmenu, m.ten, SUM(ct.soluong) AS soluong
                          FROM menu m 
                          INNER JOIN chitiethoadon ct ON m.id = ct.idmenu 
                          INNER JOIN hoadon hd ON hd.mahoadon = ct.mahoadon
                          WHERE CONVERT(DATE, hd.ngaytao) >= CONVERT(DATE, DATEADD(DAY, -6, GETDATE()))
                          AND CONVERT(DATE, hd.ngaytao) <= CONVERT(DATE, GETDATE())
                          GROUP BY ct.idmenu, m.ten
                          ORDER BY SUM(ct.soluong) DESC";
            return ExecuteQuery(sql);
        }

        public DataTable GetStatisticsByMonth()
        {
            string sql = @"SELECT ct.idmenu, m.ten, SUM(ct.soluong) AS soluong
                          FROM menu m 
                          INNER JOIN chitiethoadon ct ON m.id = ct.idmenu 
                          INNER JOIN hoadon hd ON hd.mahoadon = ct.mahoadon
                          WHERE CONVERT(DATE, hd.ngaytao) >= CONVERT(DATE, DATEADD(MONTH, -1, GETDATE()))
                          AND CONVERT(DATE, hd.ngaytao) <= CONVERT(DATE, GETDATE())
                          GROUP BY ct.idmenu, m.ten
                          ORDER BY SUM(ct.soluong) DESC";
            return ExecuteQuery(sql);
        }

        private DataTable ExecuteQuery(string sql)
        {
            DataTable dt = new DataTable();
            try
            {
                KetNoi();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi truy xuất dữ liệu: " + ex.Message);
            }
            finally
            {
                NgatKn();
            }
            return dt;
        }
    }
}
