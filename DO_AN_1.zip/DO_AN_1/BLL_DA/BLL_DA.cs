﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL_DA;
using static DAL_DA.DAL;
using DTO_DA;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using DAL_DA.DAL_FORM;
using System.Data.SqlClient;
using TheArtOfDevHtmlRenderer.Adapters;
namespace BLL_DA
{
    public class BLL
    {
        DAL_FormMain formMain = new DAL_FormMain();
        DAL_quanly qlymenu = new DAL_quanly();
        DataTable dt;
        public DataTable loadquery(string query)
        {
            return formMain.dboload(query);
        }

        public int DatBan(int idban, int tongtien)
        {
            return formMain.DatBan(idban, tongtien);
        }

        public void LuuChiTiet(int mahoadon, List<DTO.ChiTietHoaDon> chitiet)
        {
            formMain.LuuChiTietHoaDon(mahoadon, chitiet);
        }

        public int thanhtoan(int idban)
        {
            return formMain.ThanhToanBan(idban);
        }

        public int ThanhToan(int tongtien)
        {
            return formMain.ThanhToanHoaDon(tongtien);
        }
        public DataTable hienthiban(int idban)
        {
            return formMain.hienthiban(idban);
        }
        public DataTable loadDM(char maDM)
        {
            return qlymenu.dboloadDM(maDM);
        }

        //THÊM MÓN VÀO MENU
        public bool ThemMonAn(int id, string name, int gia, string maDanhMuc, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(name))
            {
                errorMessage = "Tên không được để trống!";
                return false;
            }

            if (formMain.CheckIdExists(id))
            {
                errorMessage = "ID này đã tồn tại. Vui lòng chọn ID khác.";
                return false;
            }

            if (gia <= 0)
            {
                errorMessage = "Giá phải lớn hơn 0!";
                return false;
            }

            if (string.IsNullOrWhiteSpace(maDanhMuc) || maDanhMuc == "Chọn danh mục")
            {
                errorMessage = "Vui lòng chọn 1 danh mục!";
                return false;
            }

            return qlymenu.ThemMon(id, name, gia, maDanhMuc);
        }
        //

        //SỬA MÓN TRONG MENU
        public bool SuaMonAn(int id, string name, int gia, string maDanhMuc, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(name))
            {
                errorMessage = "Tên không được để trống!";
                return false;
            }
            
            if (!formMain.CheckIdExists(id))
            {
                errorMessage = "ID này không tồn tại trong menu!";
                return false;
            }

            if (gia <= 0)
            {
                errorMessage = "Giá phải lớn hơn 0!";
                return false;
            }

            if (string.IsNullOrWhiteSpace(maDanhMuc) || maDanhMuc == "Chọn danh mục")
            {
                errorMessage = "Vui lòng chọn 1 danh mục!";
                return false;
            }

            return qlymenu.SuaMenu(id, name, gia, maDanhMuc);
        }
        //XÓA MÓN TRONG MENU
        public bool XoaMon(string name_table,int id, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (!formMain.CheckIdExists(id))
            {
                errorMessage = "ID này không tồn tại trong menu!";
                return false;
            }

            return qlymenu.XoaMenu(name_table,id);
        }

        //TÌM MÓN ĂN
        public DataTable Search(string name)
        {
            return formMain.dboSearch(name);
        }

        //Xóa Hóa Đơn
        public bool XoaHD(int id, out string Mess)
        {
            Mess = string.Empty;
            if (!qlymenu.CheckMHD(id))
            {
                Mess = "ID này không tồn tại trong hóa đơn!";
                return false;
            }
            return qlymenu.XoaHoaDon(id);
        }

        //

        //Thống kê 
        public DataTable GetThongKeHoaDon(DateTime tuNgay, DateTime denNgay)
        {
            try
            {
                DataTable dt = qlymenu.ThongKeHoaDon(tuNgay, denNgay);

                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        // Xử lý cột "hinhthuc"
                        if (row[2] != DBNull.Value)
                        {
                            int HoaDon_convert = Convert.ToInt32(row[2]);
                            row[2] = HoaDon_convert == 0 ? "Uống tại quán" : "Mang đi";
                        }

                        // Xử lý cột "tinhtrang"
                        if (row["tinhtrang"] != DBNull.Value)
                        {
                            row["tinhtrang"] = Convert.ToInt32(row["tinhtrang"]) == 0 ? "Chưa thanh toán" : "Đã thanh toán";
                        }
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi xử lý dữ liệu thống kê: " + ex.Message);
            }
        }

        public DataTable GetChiTietHoaDon(int maHoaDon)
        {
            try
            {
                return qlymenu.GetChiTietHoaDon(maHoaDon);
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi xử lý chi tiết hóa đơn: " + ex.Message);
            }
        }
        //

        public DataTable chitietHD(int maHoaDon)
        {
            try
            {
                DataTable dt = qlymenu.GetChiTietHoaDon(maHoaDon);
                return dt; // Có thể thêm logic xử lý dữ liệu ở đây nếu cần
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi xử lý chi tiết hóa đơn: " + ex.Message);
            }
        }
        public DataTable loadtong(string name_table)
        {
            return qlymenu.LOAD_TONG(name_table);
        }

        public DataTable GetDuLieuInHoaDon(int maHoaDon)
        {
            try
            {
                DataTable dt = qlymenu.LayDuLieuInHoaDon(maHoaDon);
                return dt; // Có thể thêm logic xử lý nếu cần
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi xử lý dữ liệu để in hóa đơn: " + ex.Message);
            }
        }
        public DataTable loadCCB()
        {
            return formMain.GetDanhMuc();
        }
        //////////////////////////////////////
        /// BLL THỐNG KÊ                  ///
        /////////////////////////////////////
        DAL_thongke th_ke = new DAL_thongke();
        public DataTable DGV_Thongke()
        {
            try
            {
                DataTable dt = th_ke.Load_Thong_ke();

                foreach (DataRow row in dt.Rows)
                {
                    if (row[2] != DBNull.Value) // Kiểm tra giá trị không null
                    {
                        int hinhThucValue = Convert.ToInt32(row[2]);
                        row[2] = hinhThucValue == 0 ? "Uống tại quán" : "Mang đi";
                    }
                }

                // Trả về DataTable đã được xử lý
                return dt;
            }
            catch (Exception ex)
            {

            }
            return th_ke.Load_Thong_ke();
        }

        public DataTable ThongKeTheoNgay(DateTime fromDate, DateTime toDate)
        {
            DataTable dt = th_ke.Thongketheongay(fromDate, toDate);

            // Xử lý logic nghiệp vụ: chuyển đổi giá trị hinhthuc
            foreach (DataRow row in dt.Rows)
            {
                // Check and update "hình thức" column
                if (row[2] != DBNull.Value)
                {
                    row[2] = Convert.ToInt32(row[2]) == 0 ? "Uống tại quán" : "Mang đi";
                }
            }
            return dt;
        }

        public DataTable GetAllInvoicesForReport()
        {
            DataTable dt = th_ke.GetAllInvoices();
            return dt;
        }

        // Lấy hóa đơn theo khoảng thời gian cho báo cáo
        public DataTable GetInvoicesByDateRangeForReport(DateTime fromDate, DateTime toDate)
        {
            DataTable dt = th_ke.GetInvoicesByDateRange(fromDate, toDate);
            return dt;
        }

        public DataTable LoadDGV(string ccb)
        {
            dt = new DataTable();
            if(ccb=="Tất cả")
            {
                return dt = th_ke.GetAllStatistics();
            }
            else if (ccb=="Theo ngày")
            {
                return dt=th_ke.GetStatisticsByDay();
            }
            else if (ccb =="Theo tuần")
            {
                return dt = th_ke.GetStatisticsByWeek();

            }
            else if (ccb =="Theo tháng")
            {
                return dt = th_ke.GetStatisticsByMonth();
            }
            return dt;
        }
    }
}
