﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO_DA
{
    public class DTO
    {
        public class ChiTietHoaDon
        {
            public int MaHoaDon { get; set; }
            public int IdMenu { get; set; }
            public int SoLuong { get; set; }
            public int Gia { get; set; }
        }
    }
}
